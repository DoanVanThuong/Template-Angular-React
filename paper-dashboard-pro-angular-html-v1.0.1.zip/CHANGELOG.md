# CHANGE LOG

## [1.0.1] 2017-12-05
### Fixes
- update package.json
- fixed checkboxes in regular forms
- fixed wizard

## [1.0.0] 2017-06-27
### Initial Release
