import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'panels-cmp',
    templateUrl: 'panels.component.html'
})

export class PanelsComponent{}
