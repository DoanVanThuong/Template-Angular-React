# Change Log

## [1.0.1] 2017-12-18
### Changes
 - added angular logo
 - added button for documentation
 - changed price from buy buttons

## [1.0.0] 2017-12-15
### Original Release
 
