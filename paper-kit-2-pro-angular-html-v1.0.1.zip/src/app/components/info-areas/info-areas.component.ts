import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-areas',
  templateUrl: './info-areas.component.html',
  styleUrls: ['./info-areas.component.scss']
})
export class InfoAreasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
