<template>
  <nav aria-label="breadcrumb" role="navigation">
    <ol class="breadcrumb">
      <slot>

      </slot>
    </ol>
  </nav>
</template>
<script>
  export default {
    name: 'breadcrumb'
  }
</script>
<style>
</style>
